package com.local.cache;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

/*
 * The AddressCache has a max age for the elements it's storing, an add method 
 * for adding elements, a remove method for removing, a peek method which 
 * returns the most recently added element, and a take method which removes 
 * and returns the most recently added element.
 */
public class AddressCache {

	private long maxAge;
	private ConcurrentHashMap<String, CacheElement> cacheMap;
	private LinkedBlockingDeque<String> deque;

	public AddressCache(long maxAge, TimeUnit unit) {
		this.maxAge = TimeUnit.MILLISECONDS.convert(maxAge, unit);
		this.cacheMap = new ConcurrentHashMap<String, CacheElement>();
		this.deque = new LinkedBlockingDeque<String>();

		// After every clearInterval clear() would run to remove expired
		// elements.
		long clearInterval = TimeUnit.MILLISECONDS.convert(1, unit);

		if (maxAge > 0 && clearInterval > 0) {
			Thread t = new Thread(new Runnable() {
				public void run() {
					while (true) {
						try {
							Thread.sleep(clearInterval);
						} catch (InterruptedException ex) {
							ex.printStackTrace();
						}
						clear();
					}
				}
			});

			t.setDaemon(true);
			t.start();
		}
	}

	protected class CacheElement {
		private long insertionTime = System.currentTimeMillis();
		private InetAddress address;

		CacheElement(InetAddress address) {
			this.address = address;
		}

		public InetAddress getAddress() {
			return address;
		}

		public long getInsertionTime() {
			return insertionTime;
		}
	}

	/**
	 * add() method must store unique elements only (existing elements must be
	 * ignored). This will return true if the element was successfully added.
	 * 
	 * @param address
	 * @return
	 */

	public synchronized boolean add(InetAddress address) {
		CacheElement element = new CacheElement(address);
		String key = address.getHostAddress();
		CacheElement rElement = cacheMap.putIfAbsent(key, element);
		
		if (rElement == null){
			deque.addFirst(key);
			return true;
		}
		else
			return false;
	}

	/**
	 * remove() method will return true if the address was successfully removed
	 * 
	 * @param address
	 * @return
	 */
	public boolean remove(InetAddress address) {
		String key = address.getHostAddress();
		CacheElement element = null;
		if (key != null) {
			element = cacheMap.remove(key);
		}
		if (element != null){
			deque.removeLastOccurrence(key);
			return true;
		}
		else
			return false;
	}

	/**
	 * The peek() method will return the most recently added element, null if no
	 * element exists.
	 * 
	 * @return
	 */
	public InetAddress peek() {
		CacheElement element = null;
		String key = null;
		while (true) {
			key = deque.peek();
			if (key != null) {
				element = cacheMap.get(key);
			} else {
				return null;
			}
			if (element == null) {
				deque.remove(key);
			} else {
				return element.getAddress();
			}
		}
	}

	/**
	 * take() method retrieves and removes the most recently added element from
	 * the cache and waits if necessary until an element becomes available.
	 * 
	 * @return
	 */
	public InetAddress take() {
		CacheElement element = null;
		String key = null;
		while (true) {
			try {
				key = deque.take();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (key != null) {
				element = cacheMap.remove(key);
			}
			if (element == null) {
				deque.remove(key);
			} else {
				return element.getAddress();
			}
		}
	}
	
	public int size(){
		return cacheMap.size();
	}

	public void clear() {
		long now = System.currentTimeMillis();
		ArrayList<InetAddress> removeKey = null;

		removeKey = new ArrayList<InetAddress>();
		String key = null;
		CacheElement element = null;

    	//deque is also a good option here.
		for (Entry<String, CacheElement> e : cacheMap.entrySet()) {
			element = e.getValue();
			key = e.getKey();
			if (element != null && (now > (maxAge + element.getInsertionTime()))) {
				removeKey.add(element.getAddress());
			}
		}
		
		for (InetAddress k : removeKey) {
			remove(k);
		}
		Thread.yield();
	}

}