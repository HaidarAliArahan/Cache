package com.local.cache.test;

import static org.junit.Assert.*;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Test;

import com.local.cache.AddressCache;

public class AddressCacheTest {

	@Test
	public void test() throws UnknownHostException {
		AddressCache cache = new AddressCache(100,TimeUnit.SECONDS);
		InetAddress element=InetAddress.getByName("www.google.com");  
		boolean add = cache.add(element);
		Assert.assertTrue(add);
		element=InetAddress.getByName("www.facebook.com"); 
		Assert.assertTrue(cache.add(element));
		element=InetAddress.getByName("www.bing.com"); 
		Assert.assertTrue(cache.add(element));
		element=InetAddress.getByName("www.yahoo.com"); 
		Assert.assertTrue(cache.add(element));
		element=InetAddress.getByName("www.gmail.com"); 
		Assert.assertTrue(cache.add(element));
		
		Assert.assertTrue(cache.remove(InetAddress.getByName("www.google.com")));
		
		element=InetAddress.getByName("www.linkedin.com"); 
		Assert.assertTrue(cache.add(element));
		element=InetAddress.getByName("www.in.com"); 
		Assert.assertTrue(cache.add(element));
		assertEquals("No of elements in cache", 6, cache.size());
	}
	
	@Test
	public void testPeekandTake() throws UnknownHostException{
		AddressCache cache = new AddressCache(100,TimeUnit.SECONDS);
		cache.add(InetAddress.getByName("www.google.com"));
		cache.add(InetAddress.getByName("www.facebook.com"));
		cache.add(InetAddress.getByName("www.gmail.com"));
		
		Assert.assertEquals(InetAddress.getByName("www.gmail.com"), cache.peek());
		Assert.assertEquals(InetAddress.getByName("www.gmail.com"), cache.take());
		assertEquals("No of elements in cache", 2, cache.size());
		Assert.assertEquals(InetAddress.getByName("www.facebook.com"), cache.peek());
	}
	
   @Test
   public void testClear() throws UnknownHostException, InterruptedException{
	    AddressCache cache = new AddressCache(5,TimeUnit.SECONDS);
		cache.add(InetAddress.getByName("www.google.com"));
		cache.add(InetAddress.getByName("www.facebook.com"));
		
		Thread.sleep(TimeUnit.MILLISECONDS.convert(3, TimeUnit.SECONDS));
		cache.add(InetAddress.getByName("www.gmail.com"));
		assertEquals("No of elements in cache", 3, cache.size());
		Thread.sleep(TimeUnit.MILLISECONDS.convert(3, TimeUnit.SECONDS));
		assertEquals("No of elements in cache", 1, cache.size());
   }
   
   @Test
   public void testBlockingNature() throws UnknownHostException, InterruptedException{
	   AddressCache cache = new AddressCache(50,TimeUnit.SECONDS);
	   new Thread(){
		   public void run(){
			   cache.take();
		   }
	   }.start();
		   
	   cache.add(InetAddress.getByName("www.google.com"));
	   Thread.sleep(TimeUnit.MILLISECONDS.convert(1, TimeUnit.SECONDS));
	   assertEquals("No of elements in cache", 0, cache.size());
   }
	
	

}
